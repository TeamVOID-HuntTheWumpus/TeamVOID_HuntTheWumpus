from openai import OpenAI
import csv

class TriviaAI:
    # Initialize the OpenAI client with the API key
    client = OpenAI(api_key='sk-proj-EbKj7cHelpeOcbto6R37T3BlbkFJme2Sqsp0qNSpenL5hufZ')

    def __init__():
        """
        Initialize the TriviaAI class.
        """
        pass

    @staticmethod
    def get_raw():
        """
        Get raw trivia question and answer in CSV format from OpenAI.

        Returns:
        - response (str): The response from OpenAI containing the trivia question and answer.
        """
        response = TriviaAI.client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "user", "content": "Create a trivia question on the topic of programming, video games, or tech. The output should be in CSV format, with the question (including abc options) in one column and the single correct answer a, b, or c in the other. Example: What software development hosting company has an Octocat for the logo? A. Github B. AWS C. Google Cloud,A"},
            ],
            max_tokens=200, # Maximum Length
            temperature=0.7 # Variety
        )

        return response.choices[0].message.content

    @staticmethod
    def generate_new():
        """
        Generate a new trivia question and answer by processing the raw response.

        Returns:
        - fields (list): List containing the question and the correct answer.
        """
        raw = TriviaAI.get_raw()
        fields = raw.split(",") 
        return fields # Returns a list that can be converted to object

    @staticmethod
    def write_new():
        """
        Write a new trivia question and answer to the CSV file.
        """
        newQA = TriviaAI.generate_new()

        with open('questionsDatabase.csv', 'a', newline='') as file:
            writer = csv.writer(file)
            writer.writerow(newQA)
